/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['hitchd-cdn2.imgix.net', 'source.unsplash.com'],
    },
};

export default nextConfig;
